import os
import setuptools
from distutils.core import setup


def read_file_into_string(filename):
    path = os.path.abspath(os.path.dirname(__file__))
    filepath = os.path.join(path, filename)
    try:
        return open(filepath).read()
    except IOError:
        return ""


def get_readme():
    if os.path.exists("README.md"):
        return read_file_into_string("README.md")
    return ""


setup(
    name="liar",
    packages=["liar", "liar.tests", "liar.model", "liar.raw"],
    package_data={
        "liar": [
            "liar/images/animal/*.*",
            "liar/images/business/*.*",
            "liar/images/flag/*.*",
            "liar/images/people/*.*",
        ]
    },
    install_requires=["python-dateutil", "python-slugify"],
    version="1.0.1",
    description="A source of random but realistic looking data the elioWay.",
    author="Tim Bushell",
    author_email="tcbushell@gmail.com",
    url="https://elioway.gitlab.io/eliothing/liar/index.html",
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Environment :: Console",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Natural Language :: English",
        "Operating System :: OS Independent",
        "Programming Language :: Python",
        "Programming Language :: Python :: 3",
        "Topic :: Software Development :: Testing :: Mocking",
    ],
    long_description=get_readme(),
    long_description_content_type="text/markdown",
)
