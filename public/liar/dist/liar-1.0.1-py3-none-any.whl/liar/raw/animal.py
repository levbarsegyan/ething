# -*- encoding: utf-8 -*-
"""
The data is a compiled list of well known animal, insect and plant names,
each classified (Mammal, Reptile, Plant, Bug, etc) and a 200x240px or
240x200px image from the public domain.

**Usage:**

::

    from liar.iamaliar import IAmALiar
    number_records = 10
    maker = IAmALiar(number_records)

    # Use:
    from liar.model.raw import animal_raw

    # Or from scratch:
    animal_raw = {
        'name': 'animal_raw',
        'class': 'igetraw',
        'data': 'animal',
    }

    data_set = maker.get_data([animal_suffix_raw])

    for row in data_set:
        data = Model()
        data.animal = row['animal_raw']['animal']
        data.classification = row['animal_raw']['classification']
        data.img = row['animal_raw']['img']
        data.save()

Animal images are stored in "liar/liar/rawimages/animals/<img>.gif"

If you only need the animal name, use the property option:

::

    # Use:
    from liar.model.raw import animal_name_raw

    # Or from scratch:
    animal_name_raw = {
        'name': 'animal_name_raw',
        'class': 'igetraw',
        'data': 'animal',
        'property': 'animal'
    }

    data_set = maker.get_data([animal_name_raw])

    for row in data_set:
        data = Model()
        data.animal_name = row['animal_name_raw']
        data.save()

"""

animal = [
    {
        "animal": "oar fish",
        "classification": "fish",
        "img": "animals_fish_oar_fish",
    },
    {
        "animal": "pohutukawa",
        "classification": "plant",
        "img": "animals_plant_pohutukawa",
    },
    {
        "animal": "mulberry",
        "classification": "plant",
        "img": "animals_plant_mulberry",
    },
    {
        "animal": "lovebird",
        "classification": "bird",
        "img": "animals_bird_lovebird",
    },
    {
        "animal": "puku",
        "classification": "mammal",
        "img": "animals_mammal_puku",
    },
    {
        "animal": "beech",
        "classification": "plant",
        "img": "animals_plant_beech",
    },
    {
        "animal": "falcon",
        "classification": "bird",
        "img": "animals_bird_falcon",
    },
    {
        "animal": "toucan",
        "classification": "bird",
        "img": "animals_bird_toucan",
    },
    {
        "animal": "tapir",
        "classification": "mammal",
        "img": "animals_mammal_tapir",
    },
    {
        "animal": "chestnut",
        "classification": "plant",
        "img": "animals_plant_chestnut",
    },
    {
        "animal": "friar bird",
        "classification": "bird",
        "img": "animals_bird_friar_bird",
    },
    {"animal": "rose", "classification": "plant", "img": "animals_plant_rose"},
    {
        "animal": "spiraea",
        "classification": "plant",
        "img": "animals_plant_spiraea",
    },
    {
        "animal": "muskallunge",
        "classification": "fish",
        "img": "animals_fish_muskallunge",
    },
    {"animal": "porgy", "classification": "fish", "img": "animals_fish_porgy"},
    {
        "animal": "mangrove",
        "classification": "plant",
        "img": "animals_plant_mangrove",
    },
    {
        "animal": "roller",
        "classification": "bird",
        "img": "animals_bird_roller",
    },
    {
        "animal": "mole",
        "classification": "mammal",
        "img": "animals_mammal_mole",
    },
    {
        "animal": "yarrow",
        "classification": "plant",
        "img": "animals_plant_yarrow",
    },
    {
        "animal": "porcupine fish",
        "classification": "fish",
        "img": "animals_fish_porcupine_fish",
    },
    {
        "animal": "flying dragon",
        "classification": "reptile",
        "img": "animals_reptile_flying_dragon",
    },
    {
        "animal": "hazel",
        "classification": "plant",
        "img": "animals_plant_hazel",
    },
    {"animal": "borer", "classification": "bug", "img": "animals_bug_borer"},
    {
        "animal": "poditti",
        "classification": "bird",
        "img": "animals_bird_poditti",
    },
    {
        "animal": "moccasin flower",
        "classification": "plant",
        "img": "animals_plant_moccasin_flower",
    },
    {
        "animal": "agouti",
        "classification": "mammal",
        "img": "animals_mammal_agouti",
    },
    {
        "animal": "lizard's tail",
        "classification": "plant",
        "img": "animals_plant_lizard_s_tail",
    },
    {
        "animal": "olive",
        "classification": "plant",
        "img": "animals_plant_olive",
    },
    {
        "animal": "wattle bird",
        "classification": "bird",
        "img": "animals_bird_wattle_bird",
    },
    {"animal": "gnu", "classification": "mammal", "img": "animals_mammal_gnu"},
    {
        "animal": "dziggetai",
        "classification": "mammal",
        "img": "animals_mammal_dziggetai",
    },
    {
        "animal": "catnip",
        "classification": "plant",
        "img": "animals_plant_catnip",
    },
    {
        "animal": "mignonette",
        "classification": "plant",
        "img": "animals_plant_mignonette",
    },
    {
        "animal": "lorikeet",
        "classification": "bird",
        "img": "animals_bird_lorikeet",
    },
    {
        "animal": "nelumbo",
        "classification": "plant",
        "img": "animals_plant_nelumbo",
    },
    {
        "animal": "scallop",
        "classification": "invertebrate",
        "img": "animals_invertebrate_scallop",
    },
    {
        "animal": "grasshopper",
        "classification": "bug",
        "img": "animals_bug_grasshopper",
    },
    {
        "animal": "arenia",
        "classification": "invertebrate",
        "img": "animals_invertebrate_arenia",
    },
    {
        "animal": "gerbil",
        "classification": "mammal",
        "img": "animals_mammal_gerbil",
    },
    {
        "animal": "terrapin",
        "classification": "reptile",
        "img": "animals_reptile_terrapin",
    },
    {
        "animal": "rattlesnake",
        "classification": "reptile",
        "img": "animals_reptile_rattlesnake",
    },
    {"animal": "hog", "classification": "mammal", "img": "animals_mammal_hog"},
    {
        "animal": "cockscomb",
        "classification": "plant",
        "img": "animals_plant_cockscomb",
    },
    {"animal": "trout", "classification": "fish", "img": "animals_fish_trout"},
    {"animal": "atlas", "classification": "bug", "img": "animals_bug_atlas"},
    {
        "animal": "armadillo",
        "classification": "mammal",
        "img": "animals_mammal_armadillo",
    },
    {
        "animal": "klipspringer",
        "classification": "mammal",
        "img": "animals_mammal_klipspringer",
    },
    {
        "animal": "ptarmigan",
        "classification": "bird",
        "img": "animals_bird_ptarmigan",
    },
    {
        "animal": "elephant",
        "classification": "mammal",
        "img": "animals_mammal_elephant",
    },
    {
        "animal": "nidularia",
        "classification": "plant",
        "img": "animals_plant_nidularia",
    },
    {
        "animal": "cavy",
        "classification": "mammal",
        "img": "animals_mammal_cavy",
    },
    {
        "animal": "globefish",
        "classification": "fish",
        "img": "animals_fish_globefish",
    },
    {
        "animal": "jiboa",
        "classification": "reptile",
        "img": "animals_reptile_jiboa",
    },
    {
        "animal": "foxglove",
        "classification": "plant",
        "img": "animals_plant_foxglove",
    },
    {
        "animal": "tea tree",
        "classification": "plant",
        "img": "animals_plant_tea_tree",
    },
    {
        "animal": "weaver bird",
        "classification": "bird",
        "img": "animals_bird_weaver_bird",
    },
    {
        "animal": "cephalotus",
        "classification": "plant",
        "img": "animals_plant_cephalotus",
    },
    {
        "animal": "coco palm",
        "classification": "plant",
        "img": "animals_plant_coco_palm",
    },
    {
        "animal": "festuca",
        "classification": "plant",
        "img": "animals_plant_festuca",
    },
    {
        "animal": "okapi",
        "classification": "mammal",
        "img": "animals_mammal_okapi",
    },
    {"animal": "elm", "classification": "plant", "img": "animals_plant_elm"},
    {"animal": "ass", "classification": "mammal", "img": "animals_mammal_ass"},
    {
        "animal": "polecat",
        "classification": "mammal",
        "img": "animals_mammal_polecat",
    },
    {
        "animal": "shooting fish",
        "classification": "fish",
        "img": "animals_fish_shooting_fish",
    },
    {
        "animal": "mariposa",
        "classification": "fish",
        "img": "animals_fish_mariposa",
    },
    {
        "animal": "termite",
        "classification": "bug",
        "img": "animals_bug_termite",
    },
    {
        "animal": "sassafras",
        "classification": "plant",
        "img": "animals_plant_sassafras",
    },
    {
        "animal": "merlin",
        "classification": "bird",
        "img": "animals_bird_merlin",
    },
    {
        "animal": "racoon",
        "classification": "mammal",
        "img": "animals_mammal_racoon",
    },
    {
        "animal": "manakin",
        "classification": "bird",
        "img": "animals_bird_manakin",
    },
    {
        "animal": "lemming",
        "classification": "mammal",
        "img": "animals_mammal_lemming",
    },
    {"animal": "fly", "classification": "bug", "img": "animals_bug_fly"},
    {
        "animal": "dandelion",
        "classification": "plant",
        "img": "animals_plant_dandelion",
    },
    {
        "animal": "callitrix",
        "classification": "mammal",
        "img": "animals_mammal_callitrix",
    },
    {
        "animal": "baobab",
        "classification": "plant",
        "img": "animals_plant_baobab",
    },
    {
        "animal": "hare",
        "classification": "mammal",
        "img": "animals_mammal_hare",
    },
    {
        "animal": "catfish",
        "classification": "fish",
        "img": "animals_fish_catfish",
    },
    {
        "animal": "tobacco plant",
        "classification": "plant",
        "img": "animals_plant_tobacco_plant",
    },
    {
        "animal": "nightjar",
        "classification": "bird",
        "img": "animals_bird_nightjar",
    },
    {
        "animal": "earthworm",
        "classification": "invertebrate",
        "img": "animals_invertebrate_earthworm",
    },
    {
        "animal": "sea elephant",
        "classification": "mammal",
        "img": "animals_mammal_sea_elephant",
    },
    {
        "animal": "papyrus",
        "classification": "plant",
        "img": "animals_plant_papyrus",
    },
    {
        "animal": "sugar beet",
        "classification": "plant",
        "img": "animals_plant_sugar_beet",
    },
    {
        "animal": "grackle",
        "classification": "bird",
        "img": "animals_bird_grackle",
    },
    {
        "animal": "parnassia",
        "classification": "plant",
        "img": "animals_plant_parnassia",
    },
    {
        "animal": "cowpea",
        "classification": "plant",
        "img": "animals_plant_cowpea",
    },
    {
        "animal": "camomile",
        "classification": "plant",
        "img": "animals_plant_camomile",
    },
    {"animal": "kite", "classification": "bird", "img": "animals_bird_kite"},
    {
        "animal": "sloth",
        "classification": "mammal",
        "img": "animals_mammal_sloth",
    },
    {
        "animal": "plantain",
        "classification": "plant",
        "img": "animals_plant_plantain",
    },
    {
        "animal": "pentstemon",
        "classification": "plant",
        "img": "animals_plant_pentstemon",
    },
    {
        "animal": "wombat",
        "classification": "marsupial",
        "img": "animals_marsupial_wombat",
    },
    {
        "animal": "capibara",
        "classification": "mammal",
        "img": "animals_mammal_capibara",
    },
    {
        "animal": "aconite",
        "classification": "plant",
        "img": "animals_plant_aconite",
    },
    {
        "animal": "cashew branch",
        "classification": "plant",
        "img": "animals_plant_cashew_branch",
    },
    {
        "animal": "saxifrage",
        "classification": "plant",
        "img": "animals_plant_saxifrage",
    },
    {
        "animal": "lion",
        "classification": "mammal",
        "img": "animals_mammal_lion",
    },
    {
        "animal": "honey ant",
        "classification": "bug",
        "img": "animals_bug_honey_ant",
    },
    {
        "animal": "brass bass",
        "classification": "fish",
        "img": "animals_fish_brass_bass",
    },
    {"animal": "kiwi", "classification": "bird", "img": "animals_bird_kiwi"},
    {
        "animal": "aardwolf",
        "classification": "mammal",
        "img": "animals_mammal_aardwolf",
    },
    {
        "animal": "spoonbill",
        "classification": "bird",
        "img": "animals_bird_spoonbill",
    },
    {
        "animal": "banana",
        "classification": "plant",
        "img": "animals_plant_banana",
    },
    {
        "animal": "sheep laurel",
        "classification": "plant",
        "img": "animals_plant_sheep_laurel",
    },
    {
        "animal": "lark plover",
        "classification": "bird",
        "img": "animals_bird_lark_plover",
    },
    {"animal": "yew", "classification": "plant", "img": "animals_plant_yew"},
    {
        "animal": "sunfish",
        "classification": "fish",
        "img": "animals_fish_sunfish",
    },
    {"animal": "dove", "classification": "bird", "img": "animals_bird_dove"},
    {
        "animal": "ermine",
        "classification": "mammal",
        "img": "animals_mammal_ermine",
    },
    {
        "animal": "pickerel weed",
        "classification": "plant",
        "img": "animals_plant_pickerel_weed",
    },
    {"animal": "rice", "classification": "plant", "img": "animals_plant_rice"},
    {
        "animal": "paca",
        "classification": "mammal",
        "img": "animals_mammal_paca",
    },
    {
        "animal": "bandicoot",
        "classification": "marsupial",
        "img": "animals_marsupial_bandicoot",
    },
    {
        "animal": "mountain laurel",
        "classification": "plant",
        "img": "animals_plant_mountain_laurel",
    },
    {
        "animal": "cony",
        "classification": "mammal",
        "img": "animals_mammal_cony",
    },
    {
        "animal": "usnea",
        "classification": "plant",
        "img": "animals_plant_usnea",
    },
    {
        "animal": "drone beetle",
        "classification": "bug",
        "img": "animals_bug_drone_beetle",
    },
    {
        "animal": "kudu",
        "classification": "mammal",
        "img": "animals_mammal_kudu",
    },
    {
        "animal": "ferret",
        "classification": "mammal",
        "img": "animals_mammal_ferret",
    },
    {
        "animal": "adiantum",
        "classification": "plant",
        "img": "animals_plant_adiantum",
    },
    {
        "animal": "hummingbird",
        "classification": "bird",
        "img": "animals_bird_hummingbird",
    },
    {
        "animal": "gander",
        "classification": "bird",
        "img": "animals_bird_gander",
    },
    {
        "animal": "mud dauber",
        "classification": "bug",
        "img": "animals_bug_mud_dauber",
    },
    {
        "animal": "barbet",
        "classification": "bird",
        "img": "animals_bird_barbet",
    },
    {
        "animal": "addax",
        "classification": "mammal",
        "img": "animals_mammal_addax",
    },
    {
        "animal": "squacco",
        "classification": "bird",
        "img": "animals_bird_squacco",
    },
    {"animal": "cicada", "classification": "bug", "img": "animals_bug_cicada"},
    {
        "animal": "hawthorn",
        "classification": "plant",
        "img": "animals_plant_hawthorn",
    },
    {"animal": "diver", "classification": "bird", "img": "animals_bird_diver"},
    {
        "animal": "cacao",
        "classification": "plant",
        "img": "animals_plant_cacao",
    },
    {
        "animal": "caracara",
        "classification": "bird",
        "img": "animals_bird_caracara",
    },
    {
        "animal": "piculet",
        "classification": "bird",
        "img": "animals_bird_piculet",
    },
    {
        "animal": "cyclamen",
        "classification": "plant",
        "img": "animals_plant_cyclamen",
    },
    {
        "animal": "ptolemy",
        "classification": "bug",
        "img": "animals_bug_ptolemy",
    },
    {
        "animal": "manatee",
        "classification": "mammal",
        "img": "animals_mammal_manatee",
    },
    {
        "animal": "tananger",
        "classification": "bird",
        "img": "animals_bird_tananger",
    },
    {
        "animal": "datura",
        "classification": "plant",
        "img": "animals_plant_datura",
    },
    {
        "animal": "leopard",
        "classification": "mammal",
        "img": "animals_mammal_cloud_leopard",
    },
    {
        "animal": "coypu",
        "classification": "mammal",
        "img": "animals_mammal_coypu",
    },
    {
        "animal": "herring",
        "classification": "fish",
        "img": "animals_fish_herring",
    },
    {
        "animal": "salamander",
        "classification": "amphibian",
        "img": "animals_amphibian_spotted_salamander",
    },
    {
        "animal": "python",
        "classification": "reptile",
        "img": "animals_reptile_python",
    },
    {"animal": "coot", "classification": "bird", "img": "animals_bird_coot"},
    {
        "animal": "painted snipe",
        "classification": "bird",
        "img": "animals_bird_painted_snipe",
    },
    {"animal": "bedbug", "classification": "bug", "img": "animals_bug_bedbug"},
    {
        "animal": "goatsucker",
        "classification": "bird",
        "img": "animals_bird_goatsucker",
    },
    {
        "animal": "dolphin",
        "classification": "mammal",
        "img": "animals_mammal_dolphin",
    },
    {
        "animal": "chinchilla",
        "classification": "mammal",
        "img": "animals_mammal_chinchilla",
    },
    {
        "animal": "shrimp",
        "classification": "invertebrate",
        "img": "animals_invertebrate_shrimp",
    },
    {
        "animal": "house fly",
        "classification": "bug",
        "img": "animals_bug_house_fly",
    },
    {"animal": "cow", "classification": "mammal", "img": "animals_mammal_cow"},
    {
        "animal": "warbler",
        "classification": "bird",
        "img": "animals_bird_warbler",
    },
    {"animal": "earwig", "classification": "bug", "img": "animals_bug_earwig"},
    {
        "animal": "vanilla",
        "classification": "plant",
        "img": "animals_plant_vanilla",
    },
    {
        "animal": "deer",
        "classification": "mammal",
        "img": "animals_mammal_deer",
    },
    {
        "animal": "pin borer",
        "classification": "bug",
        "img": "animals_bug_pin_borer",
    },
    {"animal": "shad", "classification": "fish", "img": "animals_fish_shad"},
    {
        "animal": "steppe fowl",
        "classification": "bird",
        "img": "animals_bird_steppe_fowl",
    },
    {
        "animal": "snake",
        "classification": "reptile",
        "img": "animals_reptile_snake",
    },
    {
        "animal": "gelsemium",
        "classification": "plant",
        "img": "animals_plant_gelsemium",
    },
    {
        "animal": "muntjak",
        "classification": "mammal",
        "img": "animals_mammal_muntjak",
    },
    {
        "animal": "starling",
        "classification": "bird",
        "img": "animals_bird_glossy_starling",
    },
    {
        "animal": "garlic",
        "classification": "plant",
        "img": "animals_plant_garlic",
    },
    {
        "animal": "floulder",
        "classification": "fish",
        "img": "animals_fish_floulder",
    },
    {
        "animal": "tumboa",
        "classification": "plant",
        "img": "animals_plant_tumboa",
    },
    {
        "animal": "trapa",
        "classification": "plant",
        "img": "animals_plant_trapa",
    },
    {
        "animal": "boat bill",
        "classification": "bird",
        "img": "animals_bird_boat_bill",
    },
    {
        "animal": "ginseng",
        "classification": "plant",
        "img": "animals_plant_ginseng",
    },
    {
        "animal": "strawberry pear",
        "classification": "plant",
        "img": "animals_plant_strawberry_pear",
    },
    {
        "animal": "jacamar",
        "classification": "bird",
        "img": "animals_bird_jacamar",
    },
    {"animal": "pike", "classification": "fish", "img": "animals_fish_pike"},
    {
        "animal": "nutcracker",
        "classification": "bird",
        "img": "animals_bird_nutcracker",
    },
    {
        "animal": "dionaea",
        "classification": "plant",
        "img": "animals_plant_dionaea",
    },
    {"animal": "tutu", "classification": "plant", "img": "animals_plant_tutu"},
    {
        "animal": "arbutus",
        "classification": "plant",
        "img": "animals_plant_arbutus",
    },
    {
        "animal": "fruit bat",
        "classification": "mammal",
        "img": "animals_mammal_fruit_bat",
    },
    {
        "animal": "mangabey",
        "classification": "mammal",
        "img": "animals_mammal_mangabey",
    },
    {
        "animal": "purple loosestrife",
        "classification": "plant",
        "img": "animals_plant_purple_loosestrife",
    },
    {
        "animal": "elecampane",
        "classification": "plant",
        "img": "animals_plant_elecampane",
    },
    {
        "animal": "escuerzos",
        "classification": "amphibian",
        "img": "animals_amphibian_escuerzos",
    },
    {
        "animal": "eucharis",
        "classification": "plant",
        "img": "animals_plant_eucharis",
    },
    {
        "animal": "blenny",
        "classification": "fish",
        "img": "animals_fish_blenny",
    },
    {
        "animal": "frog hopper",
        "classification": "bug",
        "img": "animals_bug_frog_hopper",
    },
    {
        "animal": "bullfinch",
        "classification": "bird",
        "img": "animals_bird_bullfinch",
    },
    {
        "animal": "swallow",
        "classification": "bird",
        "img": "animals_bird_swallow",
    },
    {
        "animal": "box elder",
        "classification": "plant",
        "img": "animals_plant_box_elder",
    },
    {
        "animal": "ginger",
        "classification": "plant",
        "img": "animals_plant_ginger",
    },
    {"animal": "teal", "classification": "bird", "img": "animals_bird_teal"},
    {
        "animal": "guillemot",
        "classification": "bird",
        "img": "animals_bird_guillemot",
    },
    {
        "animal": "bittern",
        "classification": "bird",
        "img": "animals_bird_bittern",
    },
    {"animal": "heron", "classification": "bird", "img": "animals_bird_heron"},
    {
        "animal": "urchin",
        "classification": "invertebrate",
        "img": "animals_invertebrate_urchin",
    },
    {
        "animal": "puffin",
        "classification": "bird",
        "img": "animals_bird_puffin",
    },
    {
        "animal": "sparrow",
        "classification": "bird",
        "img": "animals_bird_sparrow",
    },
    {
        "animal": "gecko",
        "classification": "reptile",
        "img": "animals_reptile_gecko",
    },
    {
        "animal": "grossbeak",
        "classification": "bird",
        "img": "animals_bird_grossbeak",
    },
    {
        "animal": "fringe tree",
        "classification": "plant",
        "img": "animals_plant_fringe_tree",
    },
    {
        "animal": "sargassum fish",
        "classification": "fish",
        "img": "animals_fish_sargassum_fish",
    },
    {"animal": "cosmia", "classification": "bug", "img": "animals_bug_cosmia"},
    {
        "animal": "baboon",
        "classification": "mammal",
        "img": "animals_mammal_baboon",
    },
    {
        "animal": "walrus",
        "classification": "mammal",
        "img": "animals_mammal_walrus",
    },
    {
        "animal": "newt",
        "classification": "amphibian",
        "img": "animals_amphibian_newt",
    },
    {
        "animal": "hammerhead",
        "classification": "fish",
        "img": "animals_fish_hammerhead",
    },
    {
        "animal": "tarsier",
        "classification": "mammal",
        "img": "animals_mammal_tarsier",
    },
    {
        "animal": "turtledove",
        "classification": "bird",
        "img": "animals_bird_turtledove",
    },
    {
        "animal": "octopus",
        "classification": "invertebrate",
        "img": "animals_invertebrate_octopus",
    },
    {
        "animal": "crab",
        "classification": "invertebrate",
        "img": "animals_invertebrate_crab",
    },
    {
        "animal": "trogapan",
        "classification": "bird",
        "img": "animals_bird_trogapan",
    },
    {
        "animal": "goshawk",
        "classification": "bird",
        "img": "animals_bird_goshawk",
    },
    {"animal": "fir", "classification": "plant", "img": "animals_plant_fir"},
    {"animal": "perch", "classification": "fish", "img": "animals_fish_perch"},
    {
        "animal": "lynx",
        "classification": "mammal",
        "img": "animals_mammal_lynx",
    },
    {
        "animal": "poison ivy",
        "classification": "plant",
        "img": "animals_plant_poison_ivy",
    },
    {
        "animal": "zebra",
        "classification": "mammal",
        "img": "animals_mammal_zebra",
    },
    {"animal": "roach", "classification": "fish", "img": "animals_fish_roach2"},
    {
        "animal": "chameleon",
        "classification": "reptile",
        "img": "animals_reptile_chameleon",
    },
    {
        "animal": "grizzley",
        "classification": "mammal",
        "img": "animals_mammal_grizzley",
    },
    {"animal": "snipe", "classification": "bird", "img": "animals_bird_snipe"},
    {
        "animal": "cinchona",
        "classification": "plant",
        "img": "animals_plant_cinchona",
    },
    {
        "animal": "parrot",
        "classification": "bird",
        "img": "animals_bird_parrot",
    },
    {
        "animal": "dragon fly",
        "classification": "bug",
        "img": "animals_bug_dragon_fly",
    },
    {
        "animal": "shrew mouse",
        "classification": "mammal",
        "img": "animals_mammal_shrew_mouse",
    },
    {
        "animal": "albatross",
        "classification": "bird",
        "img": "animals_bird_albatross",
    },
    {
        "animal": "cabbage palmetto",
        "classification": "plant",
        "img": "animals_plant_cabbage_palmetto",
    },
    {
        "animal": "mandrill",
        "classification": "mammal",
        "img": "animals_mammal_mandrill",
    },
    {"animal": "ash", "classification": "plant", "img": "animals_plant_ash"},
    {
        "animal": "tulip",
        "classification": "plant",
        "img": "animals_plant_tulip",
    },
    {"animal": "bat", "classification": "mammal", "img": "animals_mammal_bat"},
    {"animal": "ruff", "classification": "bird", "img": "animals_bird_ruff"},
    {
        "animal": "climbing fish",
        "classification": "fish",
        "img": "animals_fish_climbing_fish",
    },
    {
        "animal": "butternut",
        "classification": "plant",
        "img": "animals_plant_butternut",
    },
    {"animal": "ouzel", "classification": "bird", "img": "animals_bird_ouzel"},
    {
        "animal": "sago palm",
        "classification": "plant",
        "img": "animals_plant_sago_palm",
    },
    {
        "animal": "tamarin",
        "classification": "mammal",
        "img": "animals_mammal_tamarin",
    },
    {"animal": "teak", "classification": "plant", "img": "animals_plant_teak"},
    {
        "animal": "jack in the pulpit",
        "classification": "plant",
        "img": "animals_plant_jack_in_the_pulpit",
    },
    {
        "animal": "hippopotamus",
        "classification": "mammal",
        "img": "animals_mammal_hippopotamus",
    },
    {
        "animal": "bear",
        "classification": "mammal",
        "img": "animals_mammal_spectacled_bear",
    },
    {
        "animal": "bottle gourds",
        "classification": "plant",
        "img": "animals_plant_bottle_gourds",
    },
    {
        "animal": "medlar",
        "classification": "plant",
        "img": "animals_plant_medlar",
    },
    {
        "animal": "adder",
        "classification": "reptile",
        "img": "animals_reptile_adder",
    },
    {
        "animal": "porpoise",
        "classification": "mammal",
        "img": "animals_mammal_porpoise",
    },
    {
        "animal": "brazil nut",
        "classification": "plant",
        "img": "animals_plant_brazil_nut",
    },
    {
        "animal": "sculpin",
        "classification": "fish",
        "img": "animals_fish_sculpin",
    },
    {
        "animal": "pelican",
        "classification": "mammal",
        "img": "animals_mammal_pelican",
    },
    {
        "animal": "wheat",
        "classification": "plant",
        "img": "animals_plant_wheat",
    },
    {
        "animal": "staghorn fern",
        "classification": "plant",
        "img": "animals_plant_staghorn_fern",
    },
    {
        "animal": "sabella",
        "classification": "invertebrate",
        "img": "animals_invertebrate_sabella",
    },
    {"animal": "swan", "classification": "bird", "img": "animals_bird_swan"},
    {
        "animal": "golden wattle",
        "classification": "plant",
        "img": "animals_plant_golden_wattle",
    },
    {
        "animal": "teasel",
        "classification": "plant",
        "img": "animals_plant_teasel",
    },
    {"animal": "rhea", "classification": "bird", "img": "animals_bird_rhea"},
    {"animal": "bream", "classification": "fish", "img": "animals_fish_bream"},
    {
        "animal": "larkspur",
        "classification": "plant",
        "img": "animals_plant_larkspur",
    },
    {
        "animal": "partridge berry",
        "classification": "plant",
        "img": "animals_plant_partridge_berry",
    },
    {
        "animal": "bamboo",
        "classification": "plant",
        "img": "animals_plant_bamboo",
    },
    {
        "animal": "coati",
        "classification": "mammal",
        "img": "animals_mammal_coati",
    },
    {
        "animal": "frog",
        "classification": "amphibian",
        "img": "animals_amphibian_flying_frog",
    },
    {
        "animal": "gotwit",
        "classification": "bird",
        "img": "animals_bird_gotwit",
    },
    {
        "animal": "marmoset",
        "classification": "mammal",
        "img": "animals_mammal_marmoset",
    },
    {
        "animal": "honeysuckle",
        "classification": "plant",
        "img": "animals_plant_honeysuckle",
    },
    {
        "animal": "madder",
        "classification": "plant",
        "img": "animals_plant_madder",
    },
    {
        "animal": "geebung",
        "classification": "plant",
        "img": "animals_plant_geebung",
    },
    {
        "animal": "halibut",
        "classification": "fish",
        "img": "animals_fish_halibut",
    },
    {
        "animal": "sea cucumber",
        "classification": "invertebrate",
        "img": "animals_invertebrate_sea_cucumber",
    },
    {
        "animal": "bumble bee",
        "classification": "bug",
        "img": "animals_bug_bumble_bee",
    },
    {
        "animal": "mullet",
        "classification": "fish",
        "img": "animals_fish_mullet",
    },
    {
        "animal": "bird of paradise",
        "classification": "bird",
        "img": "animals_bird_bird_of_paradise",
    },
    {
        "animal": "ophioglossum",
        "classification": "plant",
        "img": "animals_plant_ophioglossum",
    },
    {
        "animal": "pangolin",
        "classification": "mammal",
        "img": "animals_mammal_pangolin",
    },
    {
        "animal": "basilisk",
        "classification": "reptile",
        "img": "animals_reptile_basilisk",
    },
    {
        "animal": "tesera",
        "classification": "invertebrate",
        "img": "animals_invertebrate_tesera",
    },
    {
        "animal": "squirrel",
        "classification": "mammal",
        "img": "animals_mammal_flying_squirrel",
    },
    {"animal": "locust", "classification": "bug", "img": "animals_bug_locust2"},
    {"animal": "tench", "classification": "fish", "img": "animals_fish_tench"},
    {
        "animal": "angler fish",
        "classification": "fish",
        "img": "animals_fish_angler_fish",
    },
    {
        "animal": "sheep",
        "classification": "mammal",
        "img": "animals_mammal_sheep",
    },
    {
        "animal": "yellowhammer",
        "classification": "bird",
        "img": "animals_bird_yellowhammer",
    },
    {
        "animal": "argonaut",
        "classification": "invertebrate",
        "img": "animals_invertebrate_argonaut",
    },
    {
        "animal": "swordfish",
        "classification": "fish",
        "img": "animals_fish_swordfish",
    },
    {
        "animal": "frog",
        "classification": "amphibian",
        "img": "animals_amphibian_frog",
    },
    {
        "animal": "ostrich",
        "classification": "bird",
        "img": "animals_bird_ostrich",
    },
    {
        "animal": "sugar maple",
        "classification": "plant",
        "img": "animals_plant_sugar_maple",
    },
    {
        "animal": "saint john's wort",
        "classification": "plant",
        "img": "animals_plant_saint_john_s_wort",
    },
    {
        "animal": "breadfruit",
        "classification": "plant",
        "img": "animals_plant_breadfruit",
    },
    {
        "animal": "chamois",
        "classification": "mammal",
        "img": "animals_mammal_chamois",
    },
    {
        "animal": "mare's tail",
        "classification": "plant",
        "img": "animals_plant_mare_s_tail",
    },
    {
        "animal": "moss rose",
        "classification": "plant",
        "img": "animals_plant_moss_rose",
    },
    {
        "animal": "bee eater",
        "classification": "bird",
        "img": "animals_bird_bee_eater",
    },
    {
        "animal": "echinocactus",
        "classification": "plant",
        "img": "animals_plant_echinocactus",
    },
    {
        "animal": "shellfish",
        "classification": "invertebrate",
        "img": "animals_invertebrate_shellfish",
    },
    {"animal": "hemp", "classification": "plant", "img": "animals_plant_hemp"},
    {"animal": "ram", "classification": "mammal", "img": "animals_mammal_ram"},
    {
        "animal": "wallaby",
        "classification": "marsupial",
        "img": "animals_marsupial_wallaby",
    },
    {
        "animal": "camel wasp",
        "classification": "bug",
        "img": "animals_bug_camel_wasp",
    },
    {
        "animal": "katydid",
        "classification": "bug",
        "img": "animals_bug_katydid",
    },
    {
        "animal": "echineta",
        "classification": "invertebrate",
        "img": "animals_invertebrate_echineta",
    },
    {
        "animal": "pasque flower",
        "classification": "plant",
        "img": "animals_plant_pasque_flower",
    },
    {
        "animal": "lemur",
        "classification": "mammal",
        "img": "animals_mammal_lemur",
    },
    {
        "animal": "scorpian",
        "classification": "bug",
        "img": "animals_bug_scorpian",
    },
    {
        "animal": "curlew",
        "classification": "bird",
        "img": "animals_bird_curlew",
    },
    {
        "animal": "columbine",
        "classification": "plant",
        "img": "animals_plant_columbine",
    },
    {"animal": "chub", "classification": "fish", "img": "animals_fish_chub"},
    {
        "animal": "needle bug",
        "classification": "bug",
        "img": "animals_bug_needle_bug",
    },
    {"animal": "shark", "classification": "fish", "img": "animals_fish_shark2"},
    {
        "animal": "paradise fish",
        "classification": "fish",
        "img": "animals_fish_paradise_fish",
    },
    {
        "animal": "broadtail",
        "classification": "bird",
        "img": "animals_bird_broadtail",
    },
    {
        "animal": "pica",
        "classification": "mammal",
        "img": "animals_mammal_pica",
    },
    {"animal": "changa", "classification": "bug", "img": "animals_bug_changa"},
    {
        "animal": "touche",
        "classification": "mammal",
        "img": "animals_mammal_touche",
    },
    {
        "animal": "maigre",
        "classification": "fish",
        "img": "animals_fish_maigre",
    },
    {
        "animal": "panther",
        "classification": "mammal",
        "img": "animals_mammal_panther",
    },
    {
        "animal": "chough",
        "classification": "bird",
        "img": "animals_bird_chough",
    },
    {
        "animal": "seal",
        "classification": "mammal",
        "img": "animals_mammal_seal",
    },
    {
        "animal": "sealion",
        "classification": "mammal",
        "img": "animals_mammal_sealion",
    },
    {
        "animal": "spiderwort",
        "classification": "bug",
        "img": "animals_bug_spiderwort",
    },
    {
        "animal": "odontoglossum",
        "classification": "plant",
        "img": "animals_plant_odontoglossum",
    },
    {
        "animal": "guineahen",
        "classification": "bird",
        "img": "animals_bird_guinea_hen",
    },
    {
        "animal": "wild goat",
        "classification": "mammal",
        "img": "animals_mammal_wild_goat",
    },
    {
        "animal": "goral",
        "classification": "mammal",
        "img": "animals_mammal_goral",
    },
    {
        "animal": "swallowtail",
        "classification": "bug",
        "img": "animals_bug_swallowtail",
    },
    {
        "animal": "eggplant",
        "classification": "plant",
        "img": "animals_plant_eggplant",
    },
    {
        "animal": "ape",
        "classification": "mammal",
        "img": "animals_mammal_barbary_ape",
    },
    {
        "animal": "monkey",
        "classification": "mammal",
        "img": "animals_mammal_monkey",
    },
    {
        "animal": "beisa",
        "classification": "mammal",
        "img": "animals_mammal_beisa",
    },
    {
        "animal": "spruce",
        "classification": "plant",
        "img": "animals_plant_spruce",
    },
    {"animal": "wasp", "classification": "bug", "img": "animals_bug_wasp"},
    {
        "animal": "myrtle",
        "classification": "plant",
        "img": "animals_plant_myrtle",
    },
    {
        "animal": "spider",
        "classification": "bug",
        "img": "animals_bug_trapdoor_spider",
    },
    {"animal": "ibis", "classification": "bird", "img": "animals_bird_ibis"},
    {
        "animal": "sedum",
        "classification": "plant",
        "img": "animals_plant_sedum",
    },
    {
        "animal": "canary",
        "classification": "bird",
        "img": "animals_bird_canary",
    },
    {
        "animal": "mussell",
        "classification": "invertebrate",
        "img": "animals_invertebrate_mussell",
    },
    {
        "animal": "coffer",
        "classification": "fish",
        "img": "animals_fish_coffer",
    },
    {"animal": "scup", "classification": "fish", "img": "animals_fish_scup"},
    {
        "animal": "chipmunk",
        "classification": "mammal",
        "img": "animals_mammal_chipmunk",
    },
    {
        "animal": "musquash",
        "classification": "mammal",
        "img": "animals_mammal_musquash",
    },
    {
        "animal": "liriodendron",
        "classification": "plant",
        "img": "animals_plant_liriodendron",
    },
    {
        "animal": "victoria",
        "classification": "plant",
        "img": "animals_plant_victoria",
    },
    {
        "animal": "jackal",
        "classification": "mammal",
        "img": "animals_mammal_jackal",
    },
    {
        "animal": "gannet",
        "classification": "bird",
        "img": "animals_bird_gannet",
    },
    {
        "animal": "artichoke",
        "classification": "plant",
        "img": "animals_plant_artichoke",
    },
    {
        "animal": "fennec",
        "classification": "mammal",
        "img": "animals_mammal_fennec",
    },
    {
        "animal": "paulownia",
        "classification": "plant",
        "img": "animals_plant_paulownia",
    },
    {
        "animal": "goldfinch",
        "classification": "bird",
        "img": "animals_bird_goldfinch",
    },
    {"animal": "flax", "classification": "plant", "img": "animals_plant_flax"},
    {
        "animal": "holly",
        "classification": "plant",
        "img": "animals_plant_holly",
    },
    {
        "animal": "centipede",
        "classification": "bug",
        "img": "animals_bug_centipede",
    },
    {
        "animal": "stapelia",
        "classification": "plant",
        "img": "animals_plant_stapelia",
    },
    {"animal": "charr", "classification": "fish", "img": "animals_fish_charr"},
    {
        "animal": "waxbill",
        "classification": "bird",
        "img": "animals_bird_waxbill",
    },
    {"animal": "stilt", "classification": "bird", "img": "animals_bird_stilt"},
    {
        "animal": "unicorn fish",
        "classification": "fish",
        "img": "animals_fish_unicorn_fish",
    },
    {
        "animal": "marsh marigold",
        "classification": "plant",
        "img": "animals_plant_marsh_marigold",
    },
    {
        "animal": "water lily",
        "classification": "plant",
        "img": "animals_plant_water_lily",
    },
    {"animal": "roach", "classification": "fish", "img": "animals_fish_roach"},
    {
        "animal": "fish of paradise",
        "classification": "fish",
        "img": "animals_fish_fish_of_paradise",
    },
    {
        "animal": "chiff chaff",
        "classification": "bird",
        "img": "animals_bird_chiff_chaff",
    },
    {
        "animal": "mistletoe",
        "classification": "plant",
        "img": "animals_plant_mistletoe",
    },
    {
        "animal": "tetragona",
        "classification": "invertebrate",
        "img": "animals_invertebrate_tetragona",
    },
    {
        "animal": "tse tse fly",
        "classification": "bug",
        "img": "animals_bug_tse_tse_fly",
    },
    {
        "animal": "shikepoke",
        "classification": "bird",
        "img": "animals_bird_shikepoke",
    },
    {
        "animal": "sarracenia",
        "classification": "plant",
        "img": "animals_plant_sarracenia",
    },
    {
        "animal": "mandrake",
        "classification": "plant",
        "img": "animals_plant_mandrake",
    },
    {
        "animal": "bruang",
        "classification": "mammal",
        "img": "animals_mammal_bruang",
    },
    {"animal": "weevil", "classification": "bug", "img": "animals_bug_weevil"},
    {
        "animal": "lobelia",
        "classification": "plant",
        "img": "animals_plant_lobelia",
    },
    {
        "animal": "cockatiel",
        "classification": "bird",
        "img": "animals_bird_cockatiel",
    },
    {
        "animal": "archer fish",
        "classification": "fish",
        "img": "animals_fish_archer_fish",
    },
    {
        "animal": "thorncrab",
        "classification": "invertebrate",
        "img": "animals_invertebrate_thorncrab",
    },
    {
        "animal": "harebell",
        "classification": "plant",
        "img": "animals_plant_harebell",
    },
    {
        "animal": "redpoll",
        "classification": "bird",
        "img": "animals_bird_redpoll",
    },
    {"animal": "fox", "classification": "mammal", "img": "animals_mammal_fox"},
    {
        "animal": "badger",
        "classification": "mammal",
        "img": "animals_mammal_badger",
    },
    {
        "animal": "anoa",
        "classification": "mammal",
        "img": "animals_mammal_anoa",
    },
    {
        "animal": "mangosteen",
        "classification": "plant",
        "img": "animals_plant_mangosteen",
    },
    {
        "animal": "yellowwood",
        "classification": "plant",
        "img": "animals_plant_yellowwood",
    },
    {"animal": "eel", "classification": "fish", "img": "animals_fish_eel"},
    {
        "animal": "screamer",
        "classification": "bird",
        "img": "animals_bird_screamer",
    },
    {
        "animal": "mallow",
        "classification": "plant",
        "img": "animals_plant_mallow",
    },
    {
        "animal": "passion flower",
        "classification": "plant",
        "img": "animals_plant_passion_flower",
    },
    {
        "animal": "parson bird",
        "classification": "bird",
        "img": "animals_bird_parson_bird",
    },
    {
        "animal": "furze",
        "classification": "plant",
        "img": "animals_plant_furze",
    },
    {
        "animal": "heather",
        "classification": "plant",
        "img": "animals_plant_heather",
    },
    {
        "animal": "flycatcher",
        "classification": "bird",
        "img": "animals_bird_flycatcher",
    },
    {
        "animal": "tumble bug",
        "classification": "bug",
        "img": "animals_bug_tumble_bug",
    },
    {
        "animal": "wallcreeper",
        "classification": "bird",
        "img": "animals_bird_wallcreeper",
    },
    {"animal": "finch", "classification": "bird", "img": "animals_bird_finch"},
    {
        "animal": "grouper",
        "classification": "fish",
        "img": "animals_fish_grouper",
    },
    {
        "animal": "oxen",
        "classification": "mammal",
        "img": "animals_mammal_oxen",
    },
    {
        "animal": "scooter",
        "classification": "bird",
        "img": "animals_bird_scooter",
    },
    {
        "animal": "giraffe",
        "classification": "mammal",
        "img": "animals_mammal_giraffe",
    },
    {"animal": "okra", "classification": "plant", "img": "animals_plant_okra"},
    {
        "animal": "kangaroo",
        "classification": "marsupial",
        "img": "animals_marsupial_kangaroo",
    },
    {
        "animal": "capparis",
        "classification": "plant",
        "img": "animals_plant_capparis",
    },
    {
        "animal": "raspberries",
        "classification": "plant",
        "img": "animals_plant_raspberries",
    },
    {
        "animal": "zoril",
        "classification": "mammal",
        "img": "animals_mammal_zoril",
    },
    {
        "animal": "orangutang",
        "classification": "mammal",
        "img": "animals_mammal_orangutang",
    },
    {
        "animal": "blackberry",
        "classification": "plant",
        "img": "animals_plant_blackberry",
    },
    {
        "animal": "mackeral",
        "classification": "fish",
        "img": "animals_fish_mackeral",
    },
    {
        "animal": "shrew mole",
        "classification": "mammal",
        "img": "animals_mammal_shrew_mole",
    },
    {
        "animal": "lily of the valley",
        "classification": "plant",
        "img": "animals_plant_lily_of_the_valley",
    },
    {
        "animal": "minnow",
        "classification": "fish",
        "img": "animals_fish_minnow",
    },
    {
        "animal": "amphisbaena",
        "classification": "reptile",
        "img": "animals_reptile_amphisbaena",
    },
    {
        "animal": "starnosed mole",
        "classification": "mammal",
        "img": "animals_mammal_starnosed_mole",
    },
    {
        "animal": "wax palm",
        "classification": "plant",
        "img": "animals_plant_wax_palm",
    },
    {
        "animal": "anchovy",
        "classification": "fish",
        "img": "animals_fish_anchovy",
    },
    {
        "animal": "opuntia",
        "classification": "plant",
        "img": "animals_plant_opuntia",
    },
    {
        "animal": "fly agaric",
        "classification": "plant",
        "img": "animals_plant_fly_agaric",
    },
    {
        "animal": "peacock fish",
        "classification": "fish",
        "img": "animals_fish_peacock_fish",
    },
    {
        "animal": "blue gum",
        "classification": "plant",
        "img": "animals_plant_blue_gum",
    },
    {
        "animal": "gerboa",
        "classification": "mammal",
        "img": "animals_mammal_gerboa",
    },
    {
        "animal": "crossbill",
        "classification": "bird",
        "img": "animals_bird_crossbill",
    },
    {
        "animal": "mouse lemur",
        "classification": "mammal",
        "img": "animals_mammal_mouse_lemur",
    },
    {
        "animal": "pinkroot",
        "classification": "plant",
        "img": "animals_plant_pinkroot",
    },
    {
        "animal": "kingfisher",
        "classification": "bird",
        "img": "animals_bird_kingfisher",
    },
    {"animal": "flea", "classification": "bug", "img": "animals_bug_flea"},
    {"animal": "aloe", "classification": "plant", "img": "animals_plant_aloe"},
    {
        "animal": "serval",
        "classification": "mammal",
        "img": "animals_mammal_serval",
    },
    {
        "animal": "silvereye",
        "classification": "bird",
        "img": "animals_bird_silvereye",
    },
    {
        "animal": "alligator",
        "classification": "reptile",
        "img": "animals_reptile_alligator",
    },
    {"animal": "moth", "classification": "bug", "img": "animals_bug_moth"},
    {
        "animal": "euphorbia",
        "classification": "plant",
        "img": "animals_plant_euphorbia",
    },
    {
        "animal": "sweet gum",
        "classification": "plant",
        "img": "animals_plant_sweet_gum",
    },
    {
        "animal": "tree fern",
        "classification": "plant",
        "img": "animals_plant_tree_fern",
    },
    {
        "animal": "kukkaburra",
        "classification": "bird",
        "img": "animals_bird_kukkaburra",
    },
    {"animal": "scad", "classification": "fish", "img": "animals_fish_scad"},
    {
        "animal": "reindeer",
        "classification": "mammal",
        "img": "animals_mammal_reindeer",
    },
    {
        "animal": "mink",
        "classification": "mammal",
        "img": "animals_mammal_mink",
    },
    {
        "animal": "fruit fly",
        "classification": "bug",
        "img": "animals_bug_fruit_fly",
    },
    {
        "animal": "leopard",
        "classification": "mammal",
        "img": "animals_mammal_snow_leopard",
    },
    {
        "animal": "malbrouk",
        "classification": "mammal",
        "img": "animals_mammal_malbrouk",
    },
    {
        "animal": "sand hopper",
        "classification": "bug",
        "img": "animals_bug_sand_hopper",
    },
    {
        "animal": "pigdeon",
        "classification": "bird",
        "img": "animals_bird_pigdeon",
    },
    {
        "animal": "annelid",
        "classification": "invertebrate",
        "img": "animals_invertebrate_annelid",
    },
    {"animal": "midge", "classification": "bug", "img": "animals_bug_midge"},
    {
        "animal": "blackbird",
        "classification": "bird",
        "img": "animals_bird_savannah_blackbird",
    },
    {
        "animal": "banksia",
        "classification": "plant",
        "img": "animals_plant_banksia",
    },
    {
        "animal": "henbane",
        "classification": "plant",
        "img": "animals_plant_henbane",
    },
    {
        "animal": "grouse",
        "classification": "bird",
        "img": "animals_bird_grouse",
    },
    {
        "animal": "bittersweet",
        "classification": "plant",
        "img": "animals_plant_bittersweet",
    },
    {
        "animal": "blue fin",
        "classification": "fish",
        "img": "animals_fish_blue_fin",
    },
    {
        "animal": "caiman",
        "classification": "reptile",
        "img": "animals_reptile_caiman",
    },
    {
        "animal": "horse",
        "classification": "mammal",
        "img": "animals_mammal_horse",
    },
    {
        "animal": "cougar",
        "classification": "mammal",
        "img": "animals_mammal_cougar",
    },
    {
        "animal": "tube worm",
        "classification": "invertebrate",
        "img": "animals_invertebrate_tube_worm",
    },
    {
        "animal": "chatterer",
        "classification": "bird",
        "img": "animals_bird_chatterer",
    },
    {"animal": "jay", "classification": "bird", "img": "animals_bird_jay"},
    {
        "animal": "bushbuck",
        "classification": "mammal",
        "img": "animals_mammal_bushbuck",
    },
    {
        "animal": "water hemlock",
        "classification": "plant",
        "img": "animals_plant_water_hemlock",
    },
    {"animal": "eagle", "classification": "bird", "img": "animals_bird_eagle"},
    {
        "animal": "pittosporum",
        "classification": "plant",
        "img": "animals_plant_pittosporum",
    },
    {
        "animal": "gutta percha",
        "classification": "plant",
        "img": "animals_plant_gutta_percha",
    },
    {
        "animal": "tamarind",
        "classification": "plant",
        "img": "animals_plant_tamarind",
    },
    {
        "animal": "aadvark",
        "classification": "mammal",
        "img": "animals_mammal_aadvark",
    },
    {"animal": "cat", "classification": "mammal", "img": "animals_mammal_cat"},
    {
        "animal": "starfish",
        "classification": "invertebrate",
        "img": "animals_invertebrate_starfish",
    },
    {"animal": "rook", "classification": "bird", "img": "animals_bird_rook"},
    {
        "animal": "potto",
        "classification": "mammal",
        "img": "animals_mammal_potto",
    },
    {"animal": "quail", "classification": "bird", "img": "animals_bird_quail"},
    {
        "animal": "fuchsia",
        "classification": "plant",
        "img": "animals_plant_fuchsia",
    },
    {"animal": "ivy", "classification": "plant", "img": "animals_plant_ivy"},
    {
        "animal": "dormouse",
        "classification": "mammal",
        "img": "animals_mammal_dormouse",
    },
    {
        "animal": "gorrilla",
        "classification": "mammal",
        "img": "animals_mammal_gorrilla",
    },
    {
        "animal": "warmouth",
        "classification": "fish",
        "img": "animals_fish_warmouth",
    },
    {
        "animal": "meadowlark",
        "classification": "bird",
        "img": "animals_bird_meadowlark",
    },
    {
        "animal": "butterfly plant",
        "classification": "plant",
        "img": "animals_plant_butterfly_plant",
    },
    {
        "animal": "bush dog",
        "classification": "mammal",
        "img": "animals_mammal_bush_dog",
    },
    {
        "animal": "australian nut",
        "classification": "plant",
        "img": "animals_plant_australian_nut",
    },
    {
        "animal": "physalis",
        "classification": "plant",
        "img": "animals_plant_physalis",
    },
    {
        "animal": "oncidium",
        "classification": "plant",
        "img": "animals_plant_oncidium",
    },
    {"animal": "smew", "classification": "bird", "img": "animals_bird_smew"},
    {
        "animal": "tortoise",
        "classification": "reptile",
        "img": "animals_reptile_box_tortoise",
    },
    {
        "animal": "hornbill",
        "classification": "bird",
        "img": "animals_bird_hornbill",
    },
    {
        "animal": "indian pipe",
        "classification": "plant",
        "img": "animals_plant_indian_pipe",
    },
    {
        "animal": "tinamu",
        "classification": "bird",
        "img": "animals_bird_tinamu",
    },
    {
        "animal": "phalaenopsis",
        "classification": "plant",
        "img": "animals_plant_phalaenopsis",
    },
    {
        "animal": "gouty stem",
        "classification": "plant",
        "img": "animals_plant_gouty_stem",
    },
    {
        "animal": "bullhead",
        "classification": "fish",
        "img": "animals_fish_armed_bullhead",
    },
    {
        "animal": "horseshoe",
        "classification": "invertebrate",
        "img": "animals_invertebrate_horseshoe",
    },
    {
        "animal": "wildebeest",
        "classification": "mammal",
        "img": "animals_mammal_wildebeest",
    },
    {
        "animal": "widow bird",
        "classification": "bird",
        "img": "animals_bird_widow_bird",
    },
    {
        "animal": "salamander",
        "classification": "amphibian",
        "img": "animals_amphibian_three_toad_salamander",
    },
    {
        "animal": "sting ray",
        "classification": "fish",
        "img": "animals_fish_sting_ray",
    },
    {"animal": "tit", "classification": "bird", "img": "animals_bird_tit"},
    {
        "animal": "quince",
        "classification": "plant",
        "img": "animals_plant_quince",
    },
    {
        "animal": "salmon",
        "classification": "fish",
        "img": "animals_fish_salmon",
    },
    {"animal": "swift", "classification": "bird", "img": "animals_bird_swift"},
    {
        "animal": "gulfweed",
        "classification": "plant",
        "img": "animals_plant_gulfweed",
    },
    {"animal": "gnat", "classification": "bug", "img": "animals_bug_gnat2"},
    {
        "animal": "rat kangaroo",
        "classification": "mammal",
        "img": "animals_mammal_rat_kangaroo",
    },
    {
        "animal": "pheasant",
        "classification": "bird",
        "img": "animals_bird_pheasant",
    },
    {
        "animal": "anteater",
        "classification": "mammal",
        "img": "animals_mammal_anteater",
    },
    {"animal": "tick", "classification": "bug", "img": "animals_bug_tick"},
    {
        "animal": "brisbane box",
        "classification": "plant",
        "img": "animals_plant_brisbane_box",
    },
    {
        "animal": "harrier",
        "classification": "bird",
        "img": "animals_bird_harrier",
    },
    {
        "animal": "wryneck",
        "classification": "bird",
        "img": "animals_bird_wryneck",
    },
    {
        "animal": "pomegranate",
        "classification": "plant",
        "img": "animals_plant_pomegranate",
    },
    {
        "animal": "hakea",
        "classification": "plant",
        "img": "animals_plant_hakea",
    },
    {
        "animal": "zamia",
        "classification": "plant",
        "img": "animals_plant_zamia",
    },
    {
        "animal": "hoopoe",
        "classification": "bird",
        "img": "animals_bird_hoopoe",
    },
    {
        "animal": "bluets",
        "classification": "plant",
        "img": "animals_plant_bluets",
    },
    {"animal": "fluke", "classification": "fish", "img": "animals_fish_fluke"},
    {
        "animal": "phreoryctes",
        "classification": "invertebrate",
        "img": "animals_invertebrate_phreoryctes",
    },
    {
        "animal": "loris",
        "classification": "mammal",
        "img": "animals_mammal_loris",
    },
    {
        "animal": "koala",
        "classification": "marsupial",
        "img": "animals_marsupial_koala",
    },
    {
        "animal": "file fish",
        "classification": "fish",
        "img": "animals_fish_file_fish",
    },
    {
        "animal": "turkey",
        "classification": "bird",
        "img": "animals_bird_turkey",
    },
    {
        "animal": "saki",
        "classification": "mammal",
        "img": "animals_mammal_saki",
    },
    {
        "animal": "lizard",
        "classification": "reptile",
        "img": "animals_reptile_lizard",
    },
    {"animal": "owl", "classification": "bird", "img": "animals_bird_owl"},
    {
        "animal": "mango",
        "classification": "plant",
        "img": "animals_plant_mango",
    },
    {
        "animal": "rabbit",
        "classification": "mammal",
        "img": "animals_mammal_rabbit",
    },
    {
        "animal": "hercules beetle",
        "classification": "bug",
        "img": "animals_bug_hercules_beetle",
    },
    {"animal": "oak", "classification": "plant", "img": "animals_plant_oak"},
    {"animal": "crane", "classification": "bird", "img": "animals_bird_crane"},
    {
        "animal": "vulture",
        "classification": "bird",
        "img": "animals_bird_vulture",
    },
    {
        "animal": "nuthatch",
        "classification": "bird",
        "img": "animals_bird_nuthatch",
    },
    {
        "animal": "wall rue",
        "classification": "plant",
        "img": "animals_plant_wall_rue",
    },
    {
        "animal": "jonquil",
        "classification": "plant",
        "img": "animals_plant_jonquil",
    },
    {
        "animal": "llama",
        "classification": "mammal",
        "img": "animals_mammal_llama",
    },
    {
        "animal": "shrew",
        "classification": "mammal",
        "img": "animals_mammal_shrew",
    },
    {
        "animal": "pinworm",
        "classification": "invertebrate",
        "img": "animals_invertebrate_pinworm",
    },
    {
        "animal": "tarantula",
        "classification": "bug",
        "img": "animals_bug_tarantula",
    },
    {"animal": "crow", "classification": "bird", "img": "animals_bird_crow"},
    {
        "animal": "sugar cane",
        "classification": "plant",
        "img": "animals_plant_sugar_cane",
    },
    {
        "animal": "orange",
        "classification": "plant",
        "img": "animals_plant_orange",
    },
    {
        "animal": "waratah",
        "classification": "plant",
        "img": "animals_plant_waratah",
    },
    {
        "animal": "bower bird",
        "classification": "bird",
        "img": "animals_bird_bower_bird",
    },
    {"animal": "dog", "classification": "mammal", "img": "animals_mammal_dog"},
    {
        "animal": "guinea pig",
        "classification": "mammal",
        "img": "animals_mammal_guinea_pig",
    },
    {
        "animal": "skipper",
        "classification": "bug",
        "img": "animals_bug_skipper",
    },
    {
        "animal": "fathead",
        "classification": "fish",
        "img": "animals_fish_fathead",
    },
    {
        "animal": "saberbill",
        "classification": "bird",
        "img": "animals_bird_saberbill",
    },
    {
        "animal": "bluebird",
        "classification": "bird",
        "img": "animals_bird_bluebird",
    },
    {
        "animal": "cinnamon",
        "classification": "plant",
        "img": "animals_plant_cinnamon",
    },
    {
        "animal": "spider",
        "classification": "bug",
        "img": "animals_bug_garden_spider",
    },
    {
        "animal": "turtle",
        "classification": "reptile",
        "img": "animals_reptile_turtle",
    },
    {
        "animal": "budgie",
        "classification": "bird",
        "img": "animals_bird_budgie",
    },
    {
        "animal": "sable",
        "classification": "mammal",
        "img": "animals_mammal_sable",
    },
    {
        "animal": "mouse",
        "classification": "mammal",
        "img": "animals_mammal_mouse",
    },
    {
        "animal": "sweet bay",
        "classification": "plant",
        "img": "animals_plant_sweet_bay",
    },
    {
        "animal": "oriole",
        "classification": "bird",
        "img": "animals_bird_oriole",
    },
    {"animal": "oat", "classification": "plant", "img": "animals_plant_oat"},
    {
        "animal": "utricularia",
        "classification": "plant",
        "img": "animals_plant_utricularia",
    },
    {
        "animal": "plover",
        "classification": "bird",
        "img": "animals_bird_plover",
    },
    {
        "animal": "laurel",
        "classification": "plant",
        "img": "animals_plant_laurel",
    },
    {
        "animal": "cornus",
        "classification": "plant",
        "img": "animals_plant_cornus",
    },
    {
        "animal": "hepatica",
        "classification": "plant",
        "img": "animals_plant_hepatica",
    },
    {
        "animal": "otter",
        "classification": "mammal",
        "img": "animals_mammal_sea_otter",
    },
    {
        "animal": "flour mite",
        "classification": "bug",
        "img": "animals_bug_flour_mite",
    },
    {
        "animal": "wild oat",
        "classification": "plant",
        "img": "animals_plant_wild_oat",
    },
    {
        "animal": "buzzard",
        "classification": "bird",
        "img": "animals_bird_buzzard",
    },
    {"animal": "hawk", "classification": "bird", "img": "animals_bird_hawk"},
    {
        "animal": "uji fly",
        "classification": "bug",
        "img": "animals_bug_uji_fly",
    },
    {
        "animal": "pickeral",
        "classification": "fish",
        "img": "animals_fish_pickeral",
    },
    {
        "animal": "inca weevil",
        "classification": "bug",
        "img": "animals_bug_inca_weevil",
    },
    {
        "animal": "lucern",
        "classification": "plant",
        "img": "animals_plant_lucern",
    },
    {
        "animal": "yucca",
        "classification": "plant",
        "img": "animals_plant_yucca",
    },
    {
        "animal": "gibbon",
        "classification": "mammal",
        "img": "animals_mammal_gibbon",
    },
    {
        "animal": "owl",
        "classification": "bird",
        "img": "animals_bird_long_eared_owl",
    },
    {
        "animal": "carp",
        "classification": "fish",
        "img": "animals_fish_telescope_carp",
    },
    {
        "animal": "dog rose",
        "classification": "plant",
        "img": "animals_plant_dog_rose",
    },
    {
        "animal": "ground beetle",
        "classification": "bug",
        "img": "animals_bug_ground_beetle",
    },
    {
        "animal": "mockingbird",
        "classification": "bird",
        "img": "animals_bird_mockingbird",
    },
    {
        "animal": "talapoin",
        "classification": "mammal",
        "img": "animals_mammal_talapoin",
    },
    {
        "animal": "live oak",
        "classification": "plant",
        "img": "animals_plant_live_oak",
    },
    {
        "animal": "goat",
        "classification": "mammal",
        "img": "animals_mammal_domestic_goat",
    },
    {
        "animal": "maize",
        "classification": "plant",
        "img": "animals_plant_maize",
    },
    {"animal": "dulus", "classification": "bird", "img": "animals_bird_dulus"},
    {
        "animal": "vole",
        "classification": "mammal",
        "img": "animals_mammal_vole",
    },
    {
        "animal": "hedgehog",
        "classification": "mammal",
        "img": "animals_mammal_hedgehog",
    },
    {
        "animal": "yaupon",
        "classification": "plant",
        "img": "animals_plant_yaupon",
    },
    {
        "animal": "cowslip",
        "classification": "plant",
        "img": "animals_plant_cowslip",
    },
    {
        "animal": "barberry",
        "classification": "plant",
        "img": "animals_plant_barberry",
    },
    {
        "animal": "piraya",
        "classification": "fish",
        "img": "animals_fish_piraya",
    },
    {"animal": "pike", "classification": "fish", "img": "animals_fish_pike2"},
    {
        "animal": "weasel",
        "classification": "mammal",
        "img": "animals_mammal_weasel",
    },
    {
        "animal": "buffalo",
        "classification": "mammal",
        "img": "animals_mammal_buffalo",
    },
    {
        "animal": "cassowary",
        "classification": "bird",
        "img": "animals_bird_cassowary",
    },
    {
        "animal": "thrift",
        "classification": "plant",
        "img": "animals_plant_thrift",
    },
    {
        "animal": "cow fish",
        "classification": "fish",
        "img": "animals_fish_cow_fish",
    },
    {
        "animal": "snail",
        "classification": "invertebrate",
        "img": "animals_invertebrate_snail",
    },
    {
        "animal": "salvinia",
        "classification": "plant",
        "img": "animals_plant_salvinia",
    },
    {
        "animal": "grayling",
        "classification": "fish",
        "img": "animals_fish_grayling",
    },
    {"animal": "japu", "classification": "bird", "img": "animals_bird_japu"},
    {
        "animal": "sturgeon",
        "classification": "fish",
        "img": "animals_fish_sturgeon",
    },
    {
        "animal": "shamrock",
        "classification": "plant",
        "img": "animals_plant_shamrock",
    },
    {"animal": "gull", "classification": "bird", "img": "animals_bird_gull"},
    {
        "animal": "silver maple",
        "classification": "plant",
        "img": "animals_plant_silver_maple",
    },
    {
        "animal": "civet",
        "classification": "mammal",
        "img": "animals_mammal_civet",
    },
    {
        "animal": "tropaeolum",
        "classification": "plant",
        "img": "animals_plant_tropaeolum",
    },
    {
        "animal": "fly",
        "classification": "bug",
        "img": "animals_bug_gouty_legged_fly",
    },
    {
        "animal": "death cup",
        "classification": "plant",
        "img": "animals_plant_death_cup",
    },
    {"animal": "hop", "classification": "plant", "img": "animals_plant_hop"},
    {
        "animal": "redstart",
        "classification": "bird",
        "img": "animals_bird_redstart",
    },
    {
        "animal": "brittle star",
        "classification": "invertebrate",
        "img": "animals_invertebrate_brittle_star",
    },
    {
        "animal": "bull",
        "classification": "mammal",
        "img": "animals_mammal_bull",
    },
    {
        "animal": "sweetsop",
        "classification": "plant",
        "img": "animals_plant_sweetsop",
    },
    {
        "animal": "bear",
        "classification": "mammal",
        "img": "animals_mammal_bear",
    },
    {
        "animal": "scopian",
        "classification": "bug",
        "img": "animals_bug_scopian",
    },
    {"animal": "lily", "classification": "plant", "img": "animals_plant_lily"},
    {
        "animal": "belladonna",
        "classification": "plant",
        "img": "animals_plant_belladonna",
    },
    {
        "animal": "jeffersonia",
        "classification": "plant",
        "img": "animals_plant_jeffersonia",
    },
    {
        "animal": "sheepshead",
        "classification": "fish",
        "img": "animals_fish_sheepshead",
    },
    {
        "animal": "saguin",
        "classification": "mammal",
        "img": "animals_mammal_saguin",
    },
    {"animal": "elk", "classification": "mammal", "img": "animals_mammal_elk"},
    {
        "animal": "greenbrier",
        "classification": "plant",
        "img": "animals_plant_greenbrier",
    },
    {
        "animal": "opossum",
        "classification": "marsupial",
        "img": "animals_marsupial_opossum",
    },
    {
        "animal": "climbing fern",
        "classification": "plant",
        "img": "animals_plant_climbing_fern",
    },
    {
        "animal": "minivet",
        "classification": "bird",
        "img": "animals_bird_minivet",
    },
    {
        "animal": "whip scorpion",
        "classification": "bug",
        "img": "animals_bug_whip_scorpion",
    },
    {
        "animal": "panda",
        "classification": "mammal",
        "img": "animals_mammal_panda",
    },
    {
        "animal": "tumatukuru",
        "classification": "plant",
        "img": "animals_plant_tumatukuru",
    },
    {
        "animal": "linnaea",
        "classification": "plant",
        "img": "animals_plant_linnaea",
    },
    {
        "animal": "hawkbill",
        "classification": "reptile",
        "img": "animals_reptile_hawkbill",
    },
    {
        "animal": "kentia",
        "classification": "plant",
        "img": "animals_plant_kentia",
    },
    {
        "animal": "tomfool",
        "classification": "bird",
        "img": "animals_bird_tomfool",
    },
    {"animal": "cimbex", "classification": "bug", "img": "animals_bug_cimbex"},
    {
        "animal": "tucotuco",
        "classification": "mammal",
        "img": "animals_mammal_tucotuco",
    },
    {
        "animal": "dryopteris",
        "classification": "plant",
        "img": "animals_plant_dryopteris",
    },
    {
        "animal": "meganser",
        "classification": "bird",
        "img": "animals_bird_meganser",
    },
    {
        "animal": "porcupine",
        "classification": "mammal",
        "img": "animals_mammal_porcupine",
    },
    {"animal": "cod", "classification": "fish", "img": "animals_fish_cod"},
    {
        "animal": "cotton",
        "classification": "plant",
        "img": "animals_plant_cotton",
    },
    {
        "animal": "rhino",
        "classification": "mammal",
        "img": "animals_mammal_rhino",
    },
    {
        "animal": "peacock",
        "classification": "bird",
        "img": "animals_bird_peacock",
    },
    {
        "animal": "chacma",
        "classification": "mammal",
        "img": "animals_mammal_chacma",
    },
    {"animal": "stint", "classification": "bird", "img": "animals_bird_stint"},
    {
        "animal": "garial",
        "classification": "reptile",
        "img": "animals_reptile_garial",
    },
    {
        "animal": "tasmanian",
        "classification": "marsupial",
        "img": "animals_marsupial_tasmanian",
    },
    {"animal": "thrips", "classification": "bug", "img": "animals_bug_thrips"},
    {
        "animal": "lyre bird",
        "classification": "bird",
        "img": "animals_bird_lyre_bird",
    },
    {
        "animal": "parakeet",
        "classification": "bird",
        "img": "animals_bird_parakeet",
    },
    {
        "animal": "whitefish",
        "classification": "fish",
        "img": "animals_fish_whitefish",
    },
    {
        "animal": "sandfish",
        "classification": "fish",
        "img": "animals_fish_sand_fish",
    },
    {"animal": "tunny", "classification": "fish", "img": "animals_fish_tunny"},
    {
        "animal": "goosander",
        "classification": "bird",
        "img": "animals_bird_goosander",
    },
    {
        "animal": "skunk",
        "classification": "mammal",
        "img": "animals_mammal_skunk",
    },
    {
        "animal": "sprawler",
        "classification": "bug",
        "img": "animals_bug_sprawler",
    },
    {
        "animal": "leaf insect",
        "classification": "bug",
        "img": "animals_bug_leaf_insect",
    },
    {
        "animal": "jaguar",
        "classification": "mammal",
        "img": "animals_mammal_jaguar",
    },
    {
        "animal": "crinkleroot",
        "classification": "plant",
        "img": "animals_plant_crinkleroot",
    },
    {
        "animal": "chevrotain",
        "classification": "mammal",
        "img": "animals_mammal_chevrotain",
    },
    {
        "animal": "woodchuck",
        "classification": "mammal",
        "img": "animals_mammal_woodchuck",
    },
    {
        "animal": "secretary bird",
        "classification": "bird",
        "img": "animals_bird_secretary_bird",
    },
    {"animal": "hornet", "classification": "bug", "img": "animals_bug_hornet"},
    {
        "animal": "isoetes",
        "classification": "plant",
        "img": "animals_plant_isoetes",
    },
    {
        "animal": "boa",
        "classification": "reptile",
        "img": "animals_reptile_boa",
    },
    {
        "animal": "trepany",
        "classification": "invertebrate",
        "img": "animals_invertebrate_trepany",
    },
    {
        "animal": "bison",
        "classification": "mammal",
        "img": "animals_mammal_bison",
    },
    {
        "animal": "pisdras",
        "classification": "fish",
        "img": "animals_fish_pisdras",
    },
    {
        "animal": "pelican",
        "classification": "bird",
        "img": "animals_bird_pelican",
    },
    {
        "animal": "viper",
        "classification": "reptile",
        "img": "animals_reptile_viper",
    },
    {"animal": "stork", "classification": "bird", "img": "animals_bird_stork"},
    {
        "animal": "carex",
        "classification": "plant",
        "img": "animals_plant_carex",
    },
    {
        "animal": "awantibo",
        "classification": "mammal",
        "img": "animals_mammal_awantibo",
    },
    {
        "animal": "camel",
        "classification": "mammal",
        "img": "animals_mammal_camel",
    },
    {
        "animal": "poppy",
        "classification": "plant",
        "img": "animals_plant_poppy",
    },
    {
        "animal": "leopard",
        "classification": "mammal",
        "img": "animals_mammal_leopard",
    },
    {
        "animal": "oyster",
        "classification": "invertebrate",
        "img": "animals_invertebrate_oyster",
    },
    {
        "animal": "dunlin",
        "classification": "bird",
        "img": "animals_bird_dunlin",
    },
    {
        "animal": "chicken",
        "classification": "bird",
        "img": "animals_bird_chicken",
    },
    {
        "animal": "millepede",
        "classification": "bug",
        "img": "animals_bug_millepede",
    },
    {
        "animal": "lanner",
        "classification": "bird",
        "img": "animals_bird_lanner",
    },
    {
        "animal": "flamingo",
        "classification": "bird",
        "img": "animals_bird_flamingo",
    },
    {
        "animal": "soldier beetle",
        "classification": "bug",
        "img": "animals_bug_soldier_beetle",
    },
    {
        "animal": "cooba",
        "classification": "plant",
        "img": "animals_plant_cooba",
    },
    {
        "animal": "cypripedium",
        "classification": "plant",
        "img": "animals_plant_cypripedium",
    },
    {
        "animal": "cockroach",
        "classification": "bug",
        "img": "animals_bug_cockroach",
    },
    {
        "animal": "holothurian",
        "classification": "invertebrate",
        "img": "animals_invertebrate_holothurian",
    },
    {
        "animal": "penguin",
        "classification": "bird",
        "img": "animals_bird_penguin",
    },
    {
        "animal": "souslik",
        "classification": "mammal",
        "img": "animals_mammal_souslik",
    },
    {
        "animal": "john dory",
        "classification": "fish",
        "img": "animals_fish_john_dory",
    },
    {
        "animal": "alpaca",
        "classification": "mammal",
        "img": "animals_mammal_alpaca",
    },
    {
        "animal": "quandong nut",
        "classification": "plant",
        "img": "animals_plant_quandong_nut",
    },
    {
        "animal": "tea plant",
        "classification": "plant",
        "img": "animals_plant_tea_plant",
    },
    {
        "animal": "correa",
        "classification": "plant",
        "img": "animals_plant_correa",
    },
    {
        "animal": "flower de luce",
        "classification": "plant",
        "img": "animals_plant_flower_de_luce",
    },
    {"animal": "goose", "classification": "bird", "img": "animals_bird_goose"},
    {
        "animal": "marmose",
        "classification": "marsupial",
        "img": "animals_marsupial_marmose",
    },
    {
        "animal": "tahr",
        "classification": "mammal",
        "img": "animals_mammal_tahr",
    },
    {
        "animal": "boar",
        "classification": "mammal",
        "img": "animals_mammal_boar",
    },
    {
        "animal": "fire fly",
        "classification": "bug",
        "img": "animals_bug_fire_fly",
    },
    {
        "animal": "ramarama",
        "classification": "plant",
        "img": "animals_plant_ramarama",
    },
    {
        "animal": "tortoise",
        "classification": "reptile",
        "img": "animals_reptile_tortoise",
    },
    {
        "animal": "bluegill",
        "classification": "fish",
        "img": "animals_fish_bluegill",
    },
    {
        "animal": "kestrel",
        "classification": "bird",
        "img": "animals_bird_kestrel",
    },
    {
        "animal": "cardinal",
        "classification": "bird",
        "img": "animals_bird_cardinal",
    },
    {
        "animal": "sapodilla",
        "classification": "plant",
        "img": "animals_plant_sapodilla",
    },
    {
        "animal": "squirrel",
        "classification": "mammal",
        "img": "animals_mammal_squirrel",
    },
    {
        "animal": "snowdrop",
        "classification": "plant",
        "img": "animals_plant_snowdrop",
    },
    {
        "animal": "anaconda",
        "classification": "reptile",
        "img": "animals_reptile_anaconda",
    },
    {
        "animal": "barricuda",
        "classification": "fish",
        "img": "animals_fish_barricuda",
    },
    {"animal": "gadfly", "classification": "bug", "img": "animals_bug_gadfly"},
    {
        "animal": "sabre bird",
        "classification": "bird",
        "img": "animals_bird_sabre_bird",
    },
    {
        "animal": "squid",
        "classification": "invertebrate",
        "img": "animals_invertebrate_squid",
    },
    {
        "animal": "coyote",
        "classification": "mammal",
        "img": "animals_mammal_coyote",
    },
    {"animal": "carp", "classification": "fish", "img": "animals_fish_carp"},
    {"animal": "lark", "classification": "bird", "img": "animals_bird_lark"},
    {
        "animal": "broadbill",
        "classification": "bird",
        "img": "animals_bird_broadbill",
    },
    {
        "animal": "tiger flower",
        "classification": "plant",
        "img": "animals_plant_tiger_flower",
    },
    {
        "animal": "cuckoo",
        "classification": "bird",
        "img": "animals_bird_cuckoo",
    },
    {
        "animal": "fall fish",
        "classification": "fish",
        "img": "animals_fish_fall_fish",
    },
    {
        "animal": "gopher",
        "classification": "mammal",
        "img": "animals_mammal_gopher",
    },
    {
        "animal": "kangaroo apple",
        "classification": "plant",
        "img": "animals_plant_kangaroo_apple",
    },
    {
        "animal": "lantern fly",
        "classification": "bug",
        "img": "animals_bug_lantern_fly",
    },
    {
        "animal": "remora",
        "classification": "fish",
        "img": "animals_fish_remora",
    },
    {
        "animal": "narcissus",
        "classification": "plant",
        "img": "animals_plant_narcissus",
    },
    {
        "animal": "bunting",
        "classification": "bird",
        "img": "animals_bird_bunting",
    },
    {
        "animal": "papaw",
        "classification": "plant",
        "img": "animals_plant_papaw",
    },
    {
        "animal": "sondeli",
        "classification": "mammal",
        "img": "animals_mammal_sondeli",
    },
    {
        "animal": "agama",
        "classification": "reptile",
        "img": "animals_reptile_agama",
    },
    {
        "animal": "pepper",
        "classification": "plant",
        "img": "animals_plant_pepper",
    },
    {
        "animal": "buttercup",
        "classification": "plant",
        "img": "animals_plant_buttercup",
    },
    {
        "animal": "chickadee",
        "classification": "bird",
        "img": "animals_bird_chickadee",
    },
    {
        "animal": "seatrout",
        "classification": "fish",
        "img": "animals_fish_sea_trout",
    },
    {"animal": "ant", "classification": "bug", "img": "animals_bug_ant"},
    {
        "animal": "teju",
        "classification": "reptile",
        "img": "animals_reptile_teju",
    },
    {
        "animal": "douc",
        "classification": "mammal",
        "img": "animals_mammal_douc",
    },
    {"animal": "dace", "classification": "fish", "img": "animals_fish_dace"},
    {
        "animal": "papaya",
        "classification": "plant",
        "img": "animals_plant_papaya",
    },
    {
        "animal": "talipot",
        "classification": "plant",
        "img": "animals_plant_talipot",
    },
    {"animal": "shark", "classification": "fish", "img": "animals_fish_shark"},
    {
        "animal": "fairy wren",
        "classification": "bird",
        "img": "animals_bird_fairy_wren",
    },
    {
        "animal": "lobster",
        "classification": "invertebrate",
        "img": "animals_invertebrate_lobster",
    },
    {
        "animal": "crappie",
        "classification": "fish",
        "img": "animals_fish_crappie",
    },
    {
        "animal": "thyme",
        "classification": "plant",
        "img": "animals_plant_thyme",
    },
    {"animal": "palm", "classification": "plant", "img": "animals_plant_palm"},
    {
        "animal": "stanhopea",
        "classification": "plant",
        "img": "animals_plant_stanhopea",
    },
    {
        "animal": "wolf",
        "classification": "mammal",
        "img": "animals_mammal_wolf",
    },
    {
        "animal": "wattle",
        "classification": "plant",
        "img": "animals_plant_wattle",
    },
    {
        "animal": "banyan tree",
        "classification": "plant",
        "img": "animals_plant_banyan_tree",
    },
    {
        "animal": "coffee",
        "classification": "plant",
        "img": "animals_plant_coffee",
    },
    {"animal": "tern", "classification": "bird", "img": "animals_bird_tern"},
    {"animal": "smelt", "classification": "fish", "img": "animals_fish_smelt"},
    {
        "animal": "salvia",
        "classification": "plant",
        "img": "animals_plant_salvia",
    },
    {
        "animal": "goldfish",
        "classification": "fish",
        "img": "animals_fish_goldfish",
    },
    {
        "animal": "silverfish",
        "classification": "bug",
        "img": "animals_bug_silverfish",
    },
    {
        "animal": "monitor",
        "classification": "reptile",
        "img": "animals_reptile_monitor",
    },
    {
        "animal": "begonia",
        "classification": "plant",
        "img": "animals_plant_begonia",
    },
    {"animal": "jay", "classification": "bird", "img": "animals_bird_tree_jay"},
    {
        "animal": "narwhal",
        "classification": "mammal",
        "img": "animals_mammal_narwhal",
    },
    {
        "animal": "pipe fish",
        "classification": "fish",
        "img": "animals_fish_pipe_fish",
    },
    {"animal": "opah", "classification": "fish", "img": "animals_fish_opah"},
    {
        "animal": "sepiola",
        "classification": "invertebrate",
        "img": "animals_invertebrate_sepiola",
    },
    {
        "animal": "kohl rabi",
        "classification": "plant",
        "img": "animals_plant_kohl_rabi",
    },
    {
        "animal": "butterfly",
        "classification": "bug",
        "img": "animals_bug_butterfly",
    },
    {"animal": "ruffe", "classification": "fish", "img": "animals_fish_ruffe"},
    {
        "animal": "water bug",
        "classification": "bug",
        "img": "animals_bug_water_bug",
    },
    {
        "animal": "rockfish",
        "classification": "fish",
        "img": "animals_fish_rockfish",
    },
    {
        "animal": "willow",
        "classification": "plant",
        "img": "animals_plant_willow",
    },
    {
        "animal": "otter",
        "classification": "mammal",
        "img": "animals_mammal_otter",
    },
    {
        "animal": "fieldfare",
        "classification": "bird",
        "img": "animals_bird_fieldfare",
    },
    {
        "animal": "hen",
        "classification": "bird",
        "img": "animals_bird_water_hen",
    },
    {"animal": "grebe", "classification": "bird", "img": "animals_bird_grebe"},
    {
        "animal": "cockatoo",
        "classification": "bird",
        "img": "animals_bird_cockatoo",
    },
    {
        "animal": "dogtooth violet",
        "classification": "plant",
        "img": "animals_plant_dogtooth_violet",
    },
    {
        "animal": "shrike",
        "classification": "bird",
        "img": "animals_bird_shrike",
    },
    {
        "animal": "rose beetle",
        "classification": "bug",
        "img": "animals_bug_rose_beetle",
    },
    {
        "animal": "walleye",
        "classification": "fish",
        "img": "animals_fish_walleye",
    },
    {
        "animal": "poison sumac",
        "classification": "plant",
        "img": "animals_plant_poison_sumac",
    },
    {"animal": "bass", "classification": "fish", "img": "animals_fish_bass"},
    {"animal": "pig", "classification": "mammal", "img": "animals_mammal_pig"},
    {
        "animal": "gatrolobium",
        "classification": "plant",
        "img": "animals_plant_gatrolobium",
    },
    {
        "animal": "tuatera",
        "classification": "reptile",
        "img": "animals_reptile_tuatera",
    },
    {
        "animal": "thrush",
        "classification": "bird",
        "img": "animals_bird_thrush",
    },
    {
        "animal": "mosquito",
        "classification": "bug",
        "img": "animals_bug_mosquito",
    },
    {
        "animal": "emuwren",
        "classification": "bird",
        "img": "animals_bird_emu_wren",
    },
    {
        "animal": "bidens",
        "classification": "plant",
        "img": "animals_plant_bidens",
    },
    {
        "animal": "trillium",
        "classification": "plant",
        "img": "animals_plant_trillium",
    },
    {
        "animal": "tiger",
        "classification": "mammal",
        "img": "animals_mammal_tiger",
    },
    {
        "animal": "iguana",
        "classification": "reptile",
        "img": "animals_reptile_iguana",
    },
    {
        "animal": "sagittaria",
        "classification": "plant",
        "img": "animals_plant_sagittaria",
    },
    {
        "animal": "tambourine",
        "classification": "bird",
        "img": "animals_bird_tambourine",
    },
    {
        "animal": "pipsissewa",
        "classification": "plant",
        "img": "animals_plant_pipsissewa",
    },
    {
        "animal": "bloodroot",
        "classification": "plant",
        "img": "animals_plant_bloodroot",
    },
    {"animal": "emu", "classification": "bird", "img": "animals_bird_emu"},
    {
        "animal": "celery topped pine",
        "classification": "plant",
        "img": "animals_plant_celery_topped_pine",
    },
    {
        "animal": "stipa",
        "classification": "plant",
        "img": "animals_plant_stipa",
    },
    {"animal": "pink", "classification": "plant", "img": "animals_plant_pink"},
    {
        "animal": "anemone",
        "classification": "plant",
        "img": "animals_plant_anemone",
    },
    {
        "animal": "pine sawyer",
        "classification": "bug",
        "img": "animals_bug_pine_sawyer",
    },
    {"animal": "koel", "classification": "bird", "img": "animals_bird_koel"},
    {
        "animal": "whale",
        "classification": "mammal",
        "img": "animals_mammal_whale",
    },
    {
        "animal": "paradise bird",
        "classification": "bird",
        "img": "animals_bird_paradise_bird",
    },
    {
        "animal": "stinkpot",
        "classification": "reptile",
        "img": "animals_reptile_stinkpot",
    },
    {"animal": "gnat", "classification": "bug", "img": "animals_bug_gnat"},
    {
        "animal": "antelope",
        "classification": "mammal",
        "img": "animals_mammal_antelope",
    },
    {
        "animal": "plaice",
        "classification": "fish",
        "img": "animals_fish_plaice",
    },
    {"animal": "locust", "classification": "bug", "img": "animals_bug_locust"},
    {
        "animal": "geranium",
        "classification": "plant",
        "img": "animals_plant_geranium",
    },
    {
        "animal": "chimpazee",
        "classification": "mammal",
        "img": "animals_mammal_chimpazee",
    },
    {
        "animal": "hellebore",
        "classification": "plant",
        "img": "animals_plant_hellebore",
    },
    {
        "animal": "epidendrum",
        "classification": "plant",
        "img": "animals_plant_epidendrum",
    },
    {
        "animal": "bear",
        "classification": "mammal",
        "img": "animals_mammal_glacier_bear",
    },
    {
        "animal": "hyena",
        "classification": "mammal",
        "img": "animals_mammal_hyena",
    },
    {
        "animal": "crocodile",
        "classification": "reptile",
        "img": "animals_reptile_crocodile",
    },
    {
        "animal": "sand cricket",
        "classification": "bug",
        "img": "animals_bug_sand_cricket",
    },
    {
        "animal": "beaver",
        "classification": "mammal",
        "img": "animals_mammal_beaver",
    },
    {
        "animal": "flying fish",
        "classification": "fish",
        "img": "animals_fish_flying_fish",
    },
    {
        "animal": "harrier eagle",
        "classification": "bird",
        "img": "animals_bird_harrier_eagle",
    },
    {"animal": "spider", "classification": "bug", "img": "animals_bug_spider"},
    {
        "animal": "ballan",
        "classification": "fish",
        "img": "animals_fish_ballan",
    },
    {
        "animal": "sardine",
        "classification": "fish",
        "img": "animals_fish_sardine",
    },
    {
        "animal": "grasshopper",
        "classification": "bug",
        "img": "animals_bug_grasshopper2",
    },
    {
        "animal": "jacana",
        "classification": "reptile",
        "img": "animals_reptile_jacana",
    },
    {
        "animal": "drum fish",
        "classification": "fish",
        "img": "animals_fish_drum_fish",
    },
    {
        "animal": "sailfish",
        "classification": "fish",
        "img": "animals_fish_sailfish",
    },
    {
        "animal": "nagor",
        "classification": "mammal",
        "img": "animals_mammal_nagor",
    },
    {
        "animal": "chrysanthemums",
        "classification": "plant",
        "img": "animals_plant_chrysanthemums",
    },
    {
        "animal": "scarab beetle",
        "classification": "bug",
        "img": "animals_bug_scarab_beetle",
    },
    {
        "animal": "partridge",
        "classification": "bird",
        "img": "animals_bird_partridge",
    },
    {
        "animal": "crested quail",
        "classification": "bird",
        "img": "animals_bird_crested_quail",
    },
    {
        "animal": "lupine",
        "classification": "plant",
        "img": "animals_plant_lupine",
    },
    {
        "animal": "nepenthes",
        "classification": "plant",
        "img": "animals_plant_nepenthes",
    },
    {
        "animal": "pilchard",
        "classification": "fish",
        "img": "animals_fish_pilchard",
    },
    {
        "animal": "larch",
        "classification": "plant",
        "img": "animals_plant_larch",
    },
    {
        "animal": "fringed gentian",
        "classification": "plant",
        "img": "animals_plant_fringed_gentian",
    },
    {
        "animal": "sand bur",
        "classification": "plant",
        "img": "animals_plant_sand_bur",
    },
    {
        "animal": "soy bean",
        "classification": "plant",
        "img": "animals_plant_soy_bean",
    },
    {"animal": "trout", "classification": "fish", "img": "animals_fish_trout2"},
    {
        "animal": "crocus",
        "classification": "plant",
        "img": "animals_plant_crocus",
    },
    {
        "animal": "silkworm",
        "classification": "bug",
        "img": "animals_bug_silkworm",
    },
    {
        "animal": "planerian worm",
        "classification": "invertebrate",
        "img": "animals_invertebrate_planerian_worm",
    },
    {
        "animal": "darter",
        "classification": "bird",
        "img": "animals_bird_darter",
    },
    {
        "animal": "oak pest",
        "classification": "bug",
        "img": "animals_bug_oak_pest",
    },
    {
        "animal": "paca rana",
        "classification": "mammal",
        "img": "animals_mammal_paca_rana",
    },
    {
        "animal": "currasow",
        "classification": "bird",
        "img": "animals_bird_currasow",
    },
    {
        "animal": "sequoia",
        "classification": "plant",
        "img": "animals_plant_sequoia",
    },
    {
        "animal": "buckeye",
        "classification": "plant",
        "img": "animals_plant_buckeye",
    },
    {
        "animal": "steenbok",
        "classification": "mammal",
        "img": "animals_mammal_steenbok",
    },
    {
        "animal": "jasmine",
        "classification": "plant",
        "img": "animals_plant_jasmine",
    },
    {
        "animal": "totara",
        "classification": "plant",
        "img": "animals_plant_totara",
    },
    {
        "animal": "alder",
        "classification": "plant",
        "img": "animals_plant_alder",
    },
]
