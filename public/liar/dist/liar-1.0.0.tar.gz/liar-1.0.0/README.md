![](https://elioway.gitlab.io/eliothing/liar/elio-liar-logo.png)

> Fake it until you make it **the elioWay**

# liar

A source of random but realistic looking data the elioWay.

The main tool is `IAmALiar`, which is initialised for a certain number of records, then passed definitions of a data model - the instructions for randomly building data into columns.

- [liar Documentation](https://elioway.gitlab.io/eliothing/liar)

## Installing

```shell
pip install liar
```

- [Installing liar](https://elioway.gitlab.io/eliothing/liar/installing.html)

## Seeing is Believing

```shell
git clone https://gitlab.com/eliothing/liar/
virtualenv --python=python3 venv-liar
source venv-liar/bin/activate
pip install -r requirements/local.txt
python examples/harry_potter.py
```

## TLDR

### `python examples/harry_potter.py`

### `py.test -x`

- [liar Quickstart](https://elioway.gitlab.io/eliothing/liar/quickstart.html)
- [liar Credits](https://elioway.gitlab.io/eliothing/liar/credits.html)
- [liar Issues](https://elioway.gitlab.io/eliothing/liar/issues.html)

![](https://elioway.gitlab.io/eliothing/liar/apple-touch-icon.png)

## License

[MIT](LICENSE) [Tim Bushell](mailto:tcbushell@gmail.com)
