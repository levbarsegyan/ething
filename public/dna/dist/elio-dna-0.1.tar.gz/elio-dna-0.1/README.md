![](https://elioway.gitlab.io/eliothing/dna/elio-dna-logo.png)

# dna ![experimental](https://elioway.gitlab.io/static/experimental.png "experimental")

> Crispr for databases **the elioWay**

Django models, views, forms, and templates, built out of schema.org "Things", the elioWay.

- [dna Documentation](https://elioway.gitlab.io/eliothing/dna)

## Installing

```bash
pip install elio-dna
```

- [Installing dna](https://elioway.gitlab.io/eliothing/dna/installing.html)

## Seeing is believing

```bash
git clone https://gitlab.com/eliothing/dna.git
cd dna
virtualenv --python=python3 venv-dna
source venv-dna/bin/activate
pip install -r requirements/local.txt
./init_chromosomes.sh
```

## Usage

### Settings

Add the following required settings:

```python
# settings.py
# The schema version you want your app to support
SCHEMA_VERSION = "3.9"
# List Persons and their Places (Contact Directory)
DNA_THINGS = {"Person": {"ContactPoint", "Residence"}}
# List local MovieTheater in the area with Movies playing and Available Snacks
DNA_THINGS = {"MovieTheater": {"Movie", "IndividualProduct"}}
# List Movies with actors/directors  and where playing.
DNA_THINGS = {"Movies": {"MovieTheater", "Person"}}
# List Products and their Parts and Suppliers
DNA_THINGS = {"Product": {"Part", "Organization"}}
DNA_DEPTH = 0
```

### genome Management command

To help you find the right schema Thing, use our genome explorer: `django-admin genome <class/property>`

```bash
django-admin genome Thing
django-admin genome Person
django-admin genome isbn
django-admin genome description
django-admin genome image
```

### Models

Add to your models file:

```python
# /myapp/models.py
from django.conf import settings
from dna.models import every_model

every_model(
    settings.SCHEMA_PATH,
    ["CreativeWork", "Product"],
    0,
    "chromosomes",
)
```

Then.... Django as usual!

### Mixins

Some helpful Mixins. Simply add alongside standard Django classes.

```python
from dna.forms import every_form
from dna.views import (
    EveryCreateViewMixin,
    EveryDeleteViewMixin,
    EveryDetailViewMixin,
    EveryListViewMixin,
    EveryUpdateViewMixin,
)
```

## Nutshell

```
django-admin livereload
django-admin runserver
black .
```

- [dna Quickstart](https://elioway.gitlab.io/eliothing/dna/quickstart.html)
- [dna Credits](https://elioway.gitlab.io/eliothing/dna/credits.html)

![](https://elioway.gitlab.io/eliothing/dna/apple-touch-icon.png)

## License

[MIT](LICENSE) [Tim Bushell](mailto:tcbushell@gmail.com)
