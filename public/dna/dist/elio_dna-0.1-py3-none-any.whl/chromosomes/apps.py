# -*- encoding: utf-8 -*-
from django.apps import AppConfig


class ChromosomesConfig(AppConfig):
    name = "chromosomes"
