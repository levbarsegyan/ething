default_app_config = "chromosomes.apps.ChromosomesConfig"
